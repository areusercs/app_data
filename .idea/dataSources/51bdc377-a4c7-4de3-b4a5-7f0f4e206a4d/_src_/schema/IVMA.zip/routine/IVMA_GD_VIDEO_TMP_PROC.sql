CREATE procedure IVMA_GD_VIDEO_TMP_PROC is
  v_num number := 1;
begin
--清空tmp表
delete from ivma_gd_douyin_video_tmp;
delete from ivma_gd_haokan_video_tmp;
delete from ivma_gd_huoshan_video_tmp;
delete from ivma_gd_jrtt_video_tmp;
delete from ivma_gd_kshipin_video_tmp;
delete from ivma_gd_ks_video_tmp;
delete from ivma_gd_lisp_video_tmp;
delete from ivma_gd_pipixia_video_tmp;
delete from ivma_gd_qvtt_video_tmp;
delete from ivma_gd_xigua_video_tmp;
delete from ivma_gd_xkaxiu_video_tmp;
delete from ivma_gd_ydzixun_video_tmp;

  loop
--查询待观看数据

    insert into ivma_gd_douyin_video_tmp
      (id, video_id, check_time)
      select ivma_gd_douyin_video_tmp$seq.nextval as id,
             video_id,
             check_time
        from (select id as video_id, sysdate as check_time
                from ivma_gd_douyin_video
               where rownum <= 167
                 and insert_time > sysdate - v_num*1/24
                 and insert_time <= sysdate - (v_num-1)*1/24
               order by id desc);

    insert into ivma_gd_haokan_video_tmp
      (id, video_id, check_time)
      select ivma_gd_haokan_video_tmp$seq.nextval as id,
             video_id,
             check_time
        from (select id as video_id, sysdate as check_time
                from ivma_gd_haokan_video
               where rownum <= 167
                 and insert_time > sysdate - v_num*1/24
                 and insert_time <= sysdate - (v_num-1)*1/24
               order by id desc);

    insert into ivma_gd_huoshan_video_tmp
      (id, video_id, check_time)
      select ivma_gd_huoshan_video_tmp$seq.nextval as id,
             video_id,
             check_time
        from (select id as video_id, sysdate as check_time
                from ivma_gd_huoshan_video
               where rownum <= 167
                 and insert_time > sysdate - v_num*1/24
                 and insert_time <= sysdate - (v_num-1)*1/24
               order by id desc);

    insert into ivma_gd_jrtt_video_tmp
      (id, video_id, check_time)
      select ivma_gd_jrtt_video_tmp$seq.nextval as id,
             video_id,
             check_time
        from (select id as video_id, sysdate as check_time
                from ivma_gd_jrtt_video
               where rownum <= 21
                 and insert_time > sysdate - v_num*1/24
                 and insert_time <= sysdate - (v_num-1)*1/24
               order by id desc);

  insert into ivma_gd_kshipin_video_tmp
      (id, video_id, check_time)
      select ivma_gd_kshipin_video_tmp$seq.nextval as id,
             video_id,
             check_time
        from (select id as video_id, sysdate as check_time
                from ivma_gd_kshipin_video
               where rownum <= 21
                 and insert_time > sysdate - v_num*1/24
                 and insert_time <= sysdate - (v_num-1)*1/24
               order by id desc);

  insert into ivma_gd_ks_video_tmp
      (id, video_id, check_time)
      select ivma_gd_ks_video_tmp$seq.nextval as id,
             video_id,
             check_time
        from (select id as video_id, sysdate as check_time
                from ivma_gd_ks_video
               where rownum <= 167
                 and insert_time > sysdate - v_num*1/24
                 and insert_time <= sysdate - (v_num-1)*1/24
               order by id desc);

  insert into ivma_gd_lisp_video_tmp
      (id, video_id, check_time)
      select ivma_gd_lisp_video_tmp$seq.nextval as id,
             video_id,
             check_time
        from (select id as video_id, sysdate as check_time
                from ivma_gd_lisp_video
               where rownum <= 167
                 and insert_time > sysdate - v_num*1/24
                 and insert_time <= sysdate - (v_num-1)*1/24
               order by id desc);

  insert into ivma_gd_pipixia_video_tmp
      (id, video_id, check_time)
      select ivma_gd_pipixia_video_tmp$seq.nextval as id,
             video_id,
             check_time
        from (select id as video_id, sysdate as check_time
                from ivma_gd_pipixia_video
               where rownum <= 167
                 and insert_time > sysdate - v_num*1/24
                 and insert_time <= sysdate - (v_num-1)*1/24
               order by id desc);


   insert into ivma_gd_qvtt_video_tmp
      (id, video_id, check_time)
      select ivma_gd_qvtt_video_tmp$seq.nextval as id,
             video_id,
             check_time
        from (select id as video_id, sysdate as check_time
                from ivma_gd_qvtt_video
               where rownum <= 21
                 and insert_time > sysdate - v_num*1/24
                 and insert_time <= sysdate - (v_num-1)*1/24
               order by id desc);

   insert into ivma_gd_xigua_video_tmp
      (id, video_id, check_time)
      select ivma_gd_xigua_video_tmp$seq.nextval as id,
             video_id,
             check_time
        from (select id as video_id, sysdate as check_time
                from ivma_gd_xigua_video
               where rownum <= 21
                 and insert_time > sysdate - v_num*1/24
                 and insert_time <= sysdate - (v_num-1)*1/24
               order by id desc);

   insert into ivma_gd_xkaxiu_video_tmp
      (id, video_id, check_time)
      select ivma_gd_xkaxiu_video_tmp$seq.nextval as id,
             video_id,
             check_time
        from (select id as video_id, sysdate as check_time
                from ivma_gd_xkaxiu_video
               where rownum <= 167
                 and insert_time > sysdate - v_num*1/24
                 and insert_time <= sysdate - (v_num-1)*1/24
               order by id desc);

   insert into ivma_gd_ydzixun_video_tmp
      (id, video_id, check_time)
      select ivma_gd_ydzixun_video_tmp$seq.nextval as id,
             video_id,
             check_time
        from (select id as video_id, sysdate as check_time
                from ivma_gd_ydzixun_video
               where rownum <= 167
                 and insert_time > sysdate - v_num*1/24
                 and insert_time <= sysdate - (v_num-1)*1/24
               order by id desc);


--判断是否要退出循环
    exit when v_num = 24;
    v_num := v_num + 1;
  end loop;
   
end;
/
