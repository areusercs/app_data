CREATE procedure IVMA_GD_CHECK_INFO_PROC AS
begin
  insert into ivma_gd_check_info
    (id,
     check_count,
     harm_count,
     unharm_count,
     waitcheck_count,
     check_user_id,
     count_time,
     app_name)
    select ivma_gd_check_info$seq.nextval,
           t_check.count as check_count,
           t_harm.count as harm_count,
           t_unharm.count as unharm_count,
           t_waitcheck.count as waitcheck_count,
           t_check.check_user_id as check_user_id,
           trunc(sysdate - 1) as count_time,
           'douyin' as app_name
      from (select count(*) as count, tmp.check_user_id
              from ivma_gd_douyin_video_tmp tmp
             where 1 = 1
               and tmp.check_status != 0
             group by tmp.check_user_id) t_check
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_douyin_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 1
                  group by tmp.check_status, tmp.check_user_id) t_harm
        on t_harm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_douyin_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 2
                  group by tmp.check_status, tmp.check_user_id) t_unharm
        on t_unharm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_douyin_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 3
                  group by tmp.check_status, tmp.check_user_id) t_waitcheck
        on t_waitcheck.check_user_id = t_check.check_user_id;

  insert into ivma_gd_check_info
    (id,
     check_count,
     harm_count,
     unharm_count,
     waitcheck_count,
     check_user_id,
     count_time,
     app_name)
    select ivma_gd_check_info$seq.nextval,
           t_check.count as check_count,
           t_harm.count as harm_count,
           t_unharm.count as unharm_count,
           t_waitcheck.count as waitcheck_count,
           t_check.check_user_id as check_user_id,
           trunc(sysdate - 1) as count_time,
           'haokan' as app_name
      from (select count(*) as count, tmp.check_user_id
              from ivma_gd_haokan_video_tmp tmp
             where 1 = 1
               and tmp.check_status != 0
             group by tmp.check_user_id) t_check
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_haokan_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 1
                  group by tmp.check_status, tmp.check_user_id) t_harm
        on t_harm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_haokan_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 2
                  group by tmp.check_status, tmp.check_user_id) t_unharm
        on t_unharm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_haokan_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 3
                  group by tmp.check_status, tmp.check_user_id) t_waitcheck
        on t_waitcheck.check_user_id = t_check.check_user_id;

  insert into ivma_gd_check_info
    (id,
     check_count,
     harm_count,
     unharm_count,
     waitcheck_count,
     check_user_id,
     count_time,
     app_name)
    select ivma_gd_check_info$seq.nextval,
           t_check.count as check_count,
           t_harm.count as harm_count,
           t_unharm.count as unharm_count,
           t_waitcheck.count as waitcheck_count,
           t_check.check_user_id as check_user_id,
           trunc(sysdate - 1) as count_time,
           'huoshan' as app_name
      from (select count(*) as count, tmp.check_user_id
              from ivma_gd_huoshan_video_tmp tmp
             where 1 = 1
               and tmp.check_status != 0
             group by tmp.check_user_id) t_check
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_huoshan_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 1
                  group by tmp.check_status, tmp.check_user_id) t_harm
        on t_harm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_huoshan_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 2
                  group by tmp.check_status, tmp.check_user_id) t_unharm
        on t_unharm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_huoshan_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 3
                  group by tmp.check_status, tmp.check_user_id) t_waitcheck
        on t_waitcheck.check_user_id = t_check.check_user_id;

  insert into ivma_gd_check_info
    (id,
     check_count,
     harm_count,
     unharm_count,
     waitcheck_count,
     check_user_id,
     count_time,
     app_name)
    select ivma_gd_check_info$seq.nextval,
           t_check.count as check_count,
           t_harm.count as harm_count,
           t_unharm.count as unharm_count,
           t_waitcheck.count as waitcheck_count,
           t_check.check_user_id as check_user_id,
           trunc(sysdate - 1) as count_time,
           'jrtt' as app_name
      from (select count(*) as count, tmp.check_user_id
              from ivma_gd_jrtt_video_tmp tmp
             where 1 = 1
               and tmp.check_status != 0
             group by tmp.check_user_id) t_check
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_jrtt_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 1
                  group by tmp.check_status, tmp.check_user_id) t_harm
        on t_harm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_jrtt_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 2
                  group by tmp.check_status, tmp.check_user_id) t_unharm
        on t_unharm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_jrtt_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 3
                  group by tmp.check_status, tmp.check_user_id) t_waitcheck
        on t_waitcheck.check_user_id = t_check.check_user_id;

  insert into ivma_gd_check_info
    (id,
     check_count,
     harm_count,
     unharm_count,
     waitcheck_count,
     check_user_id,
     count_time,
     app_name)
    select ivma_gd_check_info$seq.nextval,
           t_check.count as check_count,
           t_harm.count as harm_count,
           t_unharm.count as unharm_count,
           t_waitcheck.count as waitcheck_count,
           t_check.check_user_id as check_user_id,
           trunc(sysdate - 1) as count_time,
           'kshipin' as app_name
      from (select count(*) as count, tmp.check_user_id
              from ivma_gd_kshipin_video_tmp tmp
             where 1 = 1
               and tmp.check_status != 0
             group by tmp.check_user_id) t_check
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_kshipin_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 1
                  group by tmp.check_status, tmp.check_user_id) t_harm
        on t_harm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_kshipin_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 2
                  group by tmp.check_status, tmp.check_user_id) t_unharm
        on t_unharm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_kshipin_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 3
                  group by tmp.check_status, tmp.check_user_id) t_waitcheck
        on t_waitcheck.check_user_id = t_check.check_user_id;

  insert into ivma_gd_check_info
    (id,
     check_count,
     harm_count,
     unharm_count,
     waitcheck_count,
     check_user_id,
     count_time,
     app_name)
    select ivma_gd_check_info$seq.nextval,
           t_check.count as check_count,
           t_harm.count as harm_count,
           t_unharm.count as unharm_count,
           t_waitcheck.count as waitcheck_count,
           t_check.check_user_id as check_user_id,
           trunc(sysdate - 1) as count_time,
           'ks' as app_name
      from (select count(*) as count, tmp.check_user_id
              from ivma_gd_ks_video_tmp tmp
             where 1 = 1
               and tmp.check_status != 0
             group by tmp.check_user_id) t_check
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_ks_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 1
                  group by tmp.check_status, tmp.check_user_id) t_harm
        on t_harm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_ks_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 2
                  group by tmp.check_status, tmp.check_user_id) t_unharm
        on t_unharm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_ks_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 3
                  group by tmp.check_status, tmp.check_user_id) t_waitcheck
        on t_waitcheck.check_user_id = t_check.check_user_id;

  insert into ivma_gd_check_info
    (id,
     check_count,
     harm_count,
     unharm_count,
     waitcheck_count,
     check_user_id,
     count_time,
     app_name)
    select ivma_gd_check_info$seq.nextval,
           t_check.count as check_count,
           t_harm.count as harm_count,
           t_unharm.count as unharm_count,
           t_waitcheck.count as waitcheck_count,
           t_check.check_user_id as check_user_id,
           trunc(sysdate - 1) as count_time,
           'lisp' as app_name
      from (select count(*) as count, tmp.check_user_id
              from ivma_gd_lisp_video_tmp tmp
             where 1 = 1
               and tmp.check_status != 0
             group by tmp.check_user_id) t_check
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_lisp_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 1
                  group by tmp.check_status, tmp.check_user_id) t_harm
        on t_harm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_lisp_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 2
                  group by tmp.check_status, tmp.check_user_id) t_unharm
        on t_unharm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_lisp_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 3
                  group by tmp.check_status, tmp.check_user_id) t_waitcheck
        on t_waitcheck.check_user_id = t_check.check_user_id;

  insert into ivma_gd_check_info
    (id,
     check_count,
     harm_count,
     unharm_count,
     waitcheck_count,
     check_user_id,
     count_time,
     app_name)
    select ivma_gd_check_info$seq.nextval,
           t_check.count as check_count,
           t_harm.count as harm_count,
           t_unharm.count as unharm_count,
           t_waitcheck.count as waitcheck_count,
           t_check.check_user_id as check_user_id,
           trunc(sysdate - 1) as count_time,
           'pipixia' as app_name
      from (select count(*) as count, tmp.check_user_id
              from ivma_gd_pipixia_video_tmp tmp
             where 1 = 1
               and tmp.check_status != 0
             group by tmp.check_user_id) t_check
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_pipixia_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 1
                  group by tmp.check_status, tmp.check_user_id) t_harm
        on t_harm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_pipixia_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 2
                  group by tmp.check_status, tmp.check_user_id) t_unharm
        on t_unharm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_pipixia_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 3
                  group by tmp.check_status, tmp.check_user_id) t_waitcheck
        on t_waitcheck.check_user_id = t_check.check_user_id;

  insert into ivma_gd_check_info
    (id,
     check_count,
     harm_count,
     unharm_count,
     waitcheck_count,
     check_user_id,
     count_time,
     app_name)
    select ivma_gd_check_info$seq.nextval,
           t_check.count as check_count,
           t_harm.count as harm_count,
           t_unharm.count as unharm_count,
           t_waitcheck.count as waitcheck_count,
           t_check.check_user_id as check_user_id,
           trunc(sysdate - 1) as count_time,
           'qvtt' as app_name
      from (select count(*) as count, tmp.check_user_id
              from ivma_gd_qvtt_video_tmp tmp
             where 1 = 1
               and tmp.check_status != 0
             group by tmp.check_user_id) t_check
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_qvtt_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 1
                  group by tmp.check_status, tmp.check_user_id) t_harm
        on t_harm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_qvtt_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 2
                  group by tmp.check_status, tmp.check_user_id) t_unharm
        on t_unharm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_qvtt_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 3
                  group by tmp.check_status, tmp.check_user_id) t_waitcheck
        on t_waitcheck.check_user_id = t_check.check_user_id;

  insert into ivma_gd_check_info
    (id,
     check_count,
     harm_count,
     unharm_count,
     waitcheck_count,
     check_user_id,
     count_time,
     app_name)
    select ivma_gd_check_info$seq.nextval,
           t_check.count as check_count,
           t_harm.count as harm_count,
           t_unharm.count as unharm_count,
           t_waitcheck.count as waitcheck_count,
           t_check.check_user_id as check_user_id,
           trunc(sysdate - 1) as count_time,
           'xigua' as app_name
      from (select count(*) as count, tmp.check_user_id
              from ivma_gd_xigua_video_tmp tmp
             where 1 = 1
               and tmp.check_status != 0
             group by tmp.check_user_id) t_check
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_xigua_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 1
                  group by tmp.check_status, tmp.check_user_id) t_harm
        on t_harm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_xigua_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 2
                  group by tmp.check_status, tmp.check_user_id) t_unharm
        on t_unharm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_xigua_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 3
                  group by tmp.check_status, tmp.check_user_id) t_waitcheck
        on t_waitcheck.check_user_id = t_check.check_user_id;

  insert into ivma_gd_check_info
    (id,
     check_count,
     harm_count,
     unharm_count,
     waitcheck_count,
     check_user_id,
     count_time,
     app_name)
    select ivma_gd_check_info$seq.nextval,
           t_check.count as check_count,
           t_harm.count as harm_count,
           t_unharm.count as unharm_count,
           t_waitcheck.count as waitcheck_count,
           t_check.check_user_id as check_user_id,
           trunc(sysdate - 1) as count_time,
           'xkaxiu' as app_name
      from (select count(*) as count, tmp.check_user_id
              from ivma_gd_xkaxiu_video_tmp tmp
             where 1 = 1
               and tmp.check_status != 0
             group by tmp.check_user_id) t_check
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_xkaxiu_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 1
                  group by tmp.check_status, tmp.check_user_id) t_harm
        on t_harm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_xkaxiu_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 2
                  group by tmp.check_status, tmp.check_user_id) t_unharm
        on t_unharm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_xkaxiu_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 3
                  group by tmp.check_status, tmp.check_user_id) t_waitcheck
        on t_waitcheck.check_user_id = t_check.check_user_id;

  insert into ivma_gd_check_info
    (id,
     check_count,
     harm_count,
     unharm_count,
     waitcheck_count,
     check_user_id,
     count_time,
     app_name)
    select ivma_gd_check_info$seq.nextval,
           t_check.count as check_count,
           t_harm.count as harm_count,
           t_unharm.count as unharm_count,
           t_waitcheck.count as waitcheck_count,
           t_check.check_user_id as check_user_id,
           trunc(sysdate - 1) as count_time,
           'ydzixun' as app_name
      from (select count(*) as count, tmp.check_user_id
              from ivma_gd_ydzixun_video_tmp tmp
             where 1 = 1
               and tmp.check_status != 0
             group by tmp.check_user_id) t_check
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_ydzixun_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 1
                  group by tmp.check_status, tmp.check_user_id) t_harm
        on t_harm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_ydzixun_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 2
                  group by tmp.check_status, tmp.check_user_id) t_unharm
        on t_unharm.check_user_id = t_check.check_user_id
      left join (select count(*) as count, tmp.check_user_id
                   from ivma_gd_ydzixun_video_tmp tmp
                  where 1 = 1
                    and tmp.check_status = 3
                  group by tmp.check_status, tmp.check_user_id) t_waitcheck
        on t_waitcheck.check_user_id = t_check.check_user_id;

end;
/
