CREATE procedure domaincount_proc as
 num   number;
begin
  select count(*) into num from user_tables  where table_name = upper('ivma_domain_count');
  if   num=1
       then 
          execute immediate 'drop table ivma_domain_count'; 
  end   if;
  
  execute immediate 'create table ivma_domain_count
                     (id,name,domain,is_expired,item_count,source_id,insert_time,create_time,item_count_24hours,item_count_7days,item_count_30days) 
                      as
                      select id.ID,
                             id.NAME,
                             id.DOMAIN,
                             id.IS_EXPIRED,
                             iv.item_count,
                             iv.source_id,
                             iv.insert_time,
                             sysdate,
                             to_char(iv24hours.item_count),
                             to_char(iv7days.item_count),
                             to_char(iv30days.item_count)
                        from IVMA_DOMAIN id
                        left join (select count(1) item_count,
                                          t.source_id source_id,
                                          max(t.LAST_MODIFY_TIME) insert_time
                                     from IVMA_VIDEO t
                                    where t.SOURCE_TYPE = 2
                                    group by t.source_id) iv
                          on id.id = iv.source_id
                        left join (select count(1) item_count,
                                          t.source_id source_id,
                                          max(t.LAST_MODIFY_TIME) insert_time
                                     from IVMA_VIDEO t
                                    where t.SOURCE_TYPE = 2
                                      and t.LAST_MODIFY_TIME > sysdate - 1
                                    group by t.source_id) iv24hours
                          on id.id = iv24hours.source_id
                        left join (select count(1) item_count,
                                          t.source_id source_id,
                                          max(t.LAST_MODIFY_TIME) insert_time
                                     from IVMA_VIDEO t
                                    where t.SOURCE_TYPE = 2
                                      and t.LAST_MODIFY_TIME > sysdate - 7
                                    group by t.source_id) iv7days
                          on id.id = iv7days.source_id
                        left join (select count(1) item_count,
                                          t.source_id source_id,
                                          max(t.LAST_MODIFY_TIME) insert_time
                                     from IVMA_VIDEO t
                                    where t.SOURCE_TYPE = 2
                                      and t.LAST_MODIFY_TIME > sysdate - 30
                                    group by t.source_id) iv30days
                          on id.id = iv30days.source_id';
end domaincount_proc;

/
