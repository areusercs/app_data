CREATE function OSName(type in number) return varchar2 is
  Result varchar2;
begin
  if(type==1){
  Result = 'IOS';
  }else if(type==2){
  Result = '安卓';
  }else{
  Result = 'WP';
  }
  end if
  return(Result);
end OSName;
/
