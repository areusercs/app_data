CREATE procedure FMVIDEODETAIL_PROC as

begin
  insert into IVMA_STS_FMVIDEODETIAL
  (id,
   program_name,
   program_url,
   program_desc,
   program_type,
   play_total_count,
   play_add_count,
   comment_count,
   upload_user,
   upload_time,
   insert_time,
   last_modify_time,
   source_id,
   poster_url,
   program_sub_type,
   directors,
   actors,
   source_type,
   area,
   url_type,
   share_url,
   web_url,
   extra,
   app_video_id,
   video_key)
  select id,
         program_name,
         program_url,
         program_desc,
         program_type,
         play_total_count,
         play_add_count,
         comment_count,
         upload_user,
         upload_time,
         insert_time,
         last_modify_time,
         source_id,
         poster_url,
         program_sub_type,
         directors,
         actors,
         source_type,
         area,
         url_type,
         share_url,
         web_url,
         extra,
         app_video_id,
         video_key
    from ivma_video
   where 1 = 1
     and last_modify_time >
         (select nvl(max(last_modify_time), sysdate - 365)
            from IVMA_STS_FMVIDEODETIAL)
     and (program_name like '%美国之音%' or program_name like '%自由亚洲电台%' or
         program_name like '%挪威西藏之声%' or program_name like '%印度达赖电台%' or
         program_name like '%法轮功电台%' or program_name like '%台湾之音%' or
         program_name like '%英国广播%' or program_name like '%中国之音%' or
         program_name like '%德国之声%' or program_name like '%法国国际广播电台%');


end FMVIDEODETAIL_PROC;
/
