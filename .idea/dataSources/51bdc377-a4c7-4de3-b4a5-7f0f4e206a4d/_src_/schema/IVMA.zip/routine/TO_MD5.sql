CREATE FUNCTION to_md5(input_string IN VARCHAR2)
RETURN VARCHAR2 IS
retval varchar2(128);

BEGIN
  retval := convert(input_string,'ZHS16GBK');
  retval := convert(retval,'UTF8');
  retval := utl_raw.cast_to_raw(DBMS_OBFUSCATION_TOOLKIT.MD5(INPUT_STRING =>retval));
RETURN lower(retval);
END;
/
